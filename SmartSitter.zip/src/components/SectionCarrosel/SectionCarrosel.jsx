import React from 'react'
import Carrosel from './Carrosel'


function SectionCarrosel() {
  return (
    <div>
      <Carrosel/>
    </div>
  )
}

export default SectionCarrosel
